module.exports = {
  secret: "d085e813843873b62b88004c2b278a0e4726b416ec069d9cf6b4a13efb9c2835",
};
